

## If given file not available then it throws exception
'''
print('Start line')

fileObject = open("demo.txt", "r") # FileNotFoundError:

print(fileObject)

print('end line')
'''


## If given file is available then it creates file object with required mode
'''
print('Start line')

fileObject = open("demo.txt", "r") # FileNotFoundError:

print(fileObject)

print('end line')

'''


## How to get fileName and fileMode information
'''
print('Start line')

fileObject = open("demo.txt", "r") # FileNotFoundError:

print("File Name is :",fileObject.name)

print('File Mode is :', fileObject.mode)

print('end line')
'''


# How to accessing the file data (using for-loop)
'''
fileObject = open("demo.txt", "r")

for  i in fileObject:
    print(i)
'''

'''
fileObject = open("demo.txt", "r")

for  i in fileObject:
    print(i, end="")   
'''


## working with read() ##
'''
fileObject = open("demo.txt", "r")

data = fileObject.read()

print(data) 

print(len(data))
'''

## How to find the total number of words in a file
'''
fileObject = open("demo.txt", "r")

data = fileObject.read()

list_of_words = data.split()

print(list_of_words)

print("Total number of words are :",len(list_of_words))
'''

#print(len(open("demo.txt", "r").read().split()))


## How to find the total number of lines in a file
'''
fileObject = open("demo.txt", "r")

data = fileObject.read()

list_of_lines = data.splitlines()

print(list_of_lines)

print("Total number of lines are :",len(list_of_lines))
'''



## read() method
'''
fileObject = open("demo.txt", "r")

data = fileObject.read()

print(data) 
'''

## read(count) method
'''
fileObject = open("demo.txt", "r")

data = fileObject.read(4)

print(data) 
'''

'''
fileObject = open("demo.txt", "r")

data = fileObject.read(4)
print(data)

data2 = fileObject.read()
print(data2)
'''


# readline() method
'''
fileObject = open("demo.txt", "r")
data = fileObject.readline()
print(data)
'''

# readline(count) method
'''
fileObject = open("demo.txt", "r")
data = fileObject.readline(2)
print(data)
'''


'''
fileObject = open("demo.txt", "r")
data = fileObject.readline(2)
print(data)

data2 = fileObject.readline()
print(data2)
'''


# readlines() method
'''
fileObject = open("demo.txt", "r")
data = fileObject.readlines()  # ['line1', 'line2', 'line3',....]
print(data)
'''

# readlines(count) method
'''
fileObject = open("demo.txt", "r")
data = fileObject.readlines(2) # ['current_line']
print(data)
'''


## working with tell() and seek() methods
'''
fileObject = open("demo.txt", "r")

print("Initial File pointer position is :",fileObject.tell())

print(fileObject.read(4))
print("After reading data, File pointer position is :",fileObject.tell())
print()

print(fileObject.read(4))
print("After reading data, File pointer position is :",fileObject.tell())
print()

fileObject.seek(0)
print("After using seek() method, File pointer position is :",fileObject.tell())
print()

print(fileObject.read(4))
print("After reading data, File pointer position is :",fileObject.tell())
print()
'''

## working with close() method
'''
fileObject = open("demo.txt", "r")

print(fileObject.read(4))

fileObject.close()

print(fileObject.read(2)) # ValueError: I/O operation on closed file.
'''


####  working with write operation ####

## If given fileName not available then it will creates it
'''
fileObject = open("demo2.txt", "w")
print(fileObject)
'''

## If given fileName is available then it will delete it and re-create it
'''
fileObject = open("demo2.txt", "w")
print(fileObject)
'''


##
'''
fileObject = open("demo3.txt", "w")

fileObject.write('django is a web framework\ndjango is contains huge modules')

print('data created into file')
'''

##
'''
fileObject = open("demo4.txt", "w")

fileObject.write('django is a web framework\ndjango is contains huge modules')

fileObject.close()

print('data created into file')
'''

## If given fileName not available then it will create fileName
'''
fileObject = open("demo5.txt", "x")

fileObject.write('django is a web framework\ndjango is contains huge modules')

fileObject.close()

print('data created into file')
'''

## If given fileName is available then it will throws exception like FileExistsError
'''
fileObject = open("demo5.txt", "x")

fileObject.write('django is a web framework\ndjango is contains huge modules')

fileObject.close()

print('data created into file')
'''

## If given fileName not available then it will create fileName
'''
fileObject = open("demo6.txt", "a")

fileObject.write('django is a web framework\ndjango is contains huge modules')

fileObject.close()

print('data created into file')
'''

# If given fileName is available then it will append the new data at end position
'''
fileObject = open("demo6.txt", "a")

fileObject.write('\n\nPython is simple language\npython is portable language')

fileObject.close()

print('data created into file')
'''


## What is output?
'''
print('start line')

fileObject = open('demo7.txt', 'w')

fileObject.write('RESTAPI is used to communicating one app to another app')

fileObject.close()

print('end line')
'''

# What is output?
'''
print('start line')

fileObject = open('demo8.txt', 'w')

fileObject.write('RESTAPI is used to communicating one app to another app')

x = 10 / 2

print(x)

fileObject.close()

print('end line')
'''


## What is output?
'''
print('start line')

fileObject = open('demo8.txt', 'w')

fileObject.write('RESTAPI is used to communicating one app to another app')

x = 10 / 0  # ZeroDivisionError

print(x)

fileObject.close()

print('end line')
'''

### working with "with" keyword ####
'''
print('start line')

with open('demo9.txt', 'w')  as fileObject:
    fileObject.write('RESTAPI is used to communicating one app to another app')
    x = 10 / 0  # ZeroDivisionError
    print(x)
    fileObject.close()

print('end line')
'''

## How to find the word count from a given file

'''
fileObject = open('demo.txt', 'r') 

#print(fileObject.read().splitlines())

#print(fileObject.readlines())

#print(fileObject.read().split())

'''
##
'''
fileObject = open('demo.txt', 'r')

data = fileObject.read()

list_of_words = data.split()

word_dict = {}

for word in list_of_words:
    if word not in word_dict:
        word_dict[word] = 1
    else:
        word_dict[word] = word_dict[word] + 1

print(word_dict)

'''


## Find the vowels count
'''
fileObject = open('demo.txt', 'r')

data = fileObject.read()  
   
vowels = "aeiouAEIOU"

count = 0

for char in data:
    if char in vowels:
        count = count + 1
        
print("Total number of vowels in a file :",count)       
'''

## find the first word of every line in a file
'''
for line in open('demo.txt', 'r').readlines():
    print(line.split()[0])
'''

##### working with  "os"  module #####

# getcwd()
'''
import os
print("Current working directory is :",os.getcwd())
'''

#listdir()
'''
import os
print(os.listdir())
'''

# rename('current_fileName', 'new_fileName')

'''
import os

os.rename('demo9.txt', 'sample.txt')

print('File name renamed successfully!')
'''

# remove("current_fileName")

# if given fileName not available then it throws exception like FileNotFoundError:
'''
import os

os.remove('sample2.txt')

print('File name removed successfully!')
'''

# if given fileName is available then it removes given file:
'''
import os

os.remove('sample.txt')

print('File name removed successfully!')
'''

## creating directory and change directory
'''
import os
print("Current working directory is :",os.getcwd())

os.mkdir('Django')

os.chdir('Django')
print("Current working directory is :",os.getcwd())
'''



## finding the parent direcory
'''
import os
print("Current working directory is :",os.getcwd())

os.chdir('Django')
print("Current working directory is :",os.getcwd())

os.chdir(os.pardir)
print("Current working directory is :",os.getcwd())
'''


## working with isfile() 
'''
import os

result1 = os.path.isfile('D:\8AM@Python\Files\demo.txt')
print(result1)

result2 = os.path.isfile('D:\8AM@Python\Files\Django')
print(result2)
'''

## working with isdir() menthod
'''
import os

result1 = os.path.isdir('D:\8AM@Python\Files\demo.txt')
print(result1)

result2 = os.path.isdir('D:\8AM@Python\Files\Django')
print(result2)
'''

# basename()
'''
import os
result1 = os.path.basename('D:\8AM@Python\Files\demo.txt')
print(result1)
'''

# split()
'''
import os
result1 = os.path.split('D:\8AM@Python\Files\demo.txt')
print(result1)
'''

# join()
'''
import os
result1 = os.path.join("D:\8AM@Python\Files" , "demo.txt")
print(result1)
'''

#dirname
'''
import os
result1 = os.path.dirname("D:\8AM@Python\Files\demo.txt")
print(result1)
'''

## walk()

import os
result1 = os.walk("/8AM@Python/Files")
print(tuple(result1))



























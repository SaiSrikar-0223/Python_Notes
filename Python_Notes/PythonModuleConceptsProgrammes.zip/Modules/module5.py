
## By default a module is loading only one time in python
'''
import module4

import module4

import module4
'''

## How to realod a module more than one time in python
'''
import module4

import  importlib
importlib.reload(module4)

importlib.reload(module4)
'''




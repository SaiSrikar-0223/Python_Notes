
'''
import module2
module2.add()
module2.sub()
'''


'''
from module2  import  *
add()
sub()
'''

from module2  import add, sub

def mul():
    n1 = int(input('Enter first number :'))
    n2 = int(input('Enter second number :'))
    return n1 * n2

def div():
    n1 = int(input('Enter first number :'))
    n2 = int(input('Enter second number :'))
    return n1 / n2


while True:
    print('Please select your required operation:')
    print('1. Addition')
    print('2. Subtration')
    print('3. Multiplication')
    print('4. Divition')
    print('5. Do you want exit?')

    value = input() # 2

    if value == '1':
        print("The addition result is :",add())
        break
    
    elif value == '2':
        print("The subtraction result is :",sub())
        break
    
    elif value == '3':
        print("The multiplication result is :",mul())
        break
    elif value == '4':
        print("The division result is :",div())
        break
    elif value == '5':
        break
    
    else:
        print('please select valid option')
        
    
        
        
    
    

'''
print("The addition result is :",add())

print("The subtraction result is :",sub())

print("The multiplication result is :",mul())

print("The division result is :",div())
'''



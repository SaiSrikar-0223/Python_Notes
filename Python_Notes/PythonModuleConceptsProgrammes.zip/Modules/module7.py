
import  module6
print()

print(module6.__doc__)
print()

print(dir())
print()

print(__file__)
print()

print(help('module6'))



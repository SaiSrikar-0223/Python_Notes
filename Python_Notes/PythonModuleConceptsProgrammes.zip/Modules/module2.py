
def add():
    n1 = int(input('Enter first number :'))
    n2 = int(input('Enter second number :'))
    return n1 + n2


def sub():
    n1 = int(input('Enter first number :'))
    n2 = int(input('Enter second number :'))
    return n1 - n2



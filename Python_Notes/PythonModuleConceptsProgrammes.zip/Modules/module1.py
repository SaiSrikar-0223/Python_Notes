
print('Welcome to Modules Concept')

def message():
    print('I am from a message() function')

message()

def add():
    n1 = int(input('Enter first number :'))
    n2 = int(input('Enter second number :'))
    result = n1 + n2
    return result

print(add())


x = 10
print(x)

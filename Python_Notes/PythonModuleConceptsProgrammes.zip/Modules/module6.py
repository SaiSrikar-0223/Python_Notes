'''module6 contains two functions like add(a,b), sub(a,b)
two variables like x,y'''

x = 10
y = 20

print("Result :", x + y)

def add(a,b):
    '''It returns addition value'''
    print('Value of a is :', a)
    print('Value of b is :', b)
    '''Print the result of given values'''
    print('The addition result is :', a + b)


def sub(a,b):
    '''None'''
    print('Value of a is :', a)
    print('Value of b is :', b)
    print('The subtraction rsult is :', a - b)


add(30,40)
print(add.__doc__)
print(sub.__doc__)
#print(module6.__doc__)  # NameError: name 'module6' is not defined


print(help('module6'))
print()

print(dir())








## If given file not available then it throws exception
'''
print('Start line')

fileObject = open("demo.txt", "r") # FileNotFoundError:

print(fileObject)

print('end line')
'''


## If given file is available then it creates file object with required mode
'''
print('Start line')

fileObject = open("demo.txt", "r") # FileNotFoundError:

print(fileObject)

print('end line')

'''


## How to get fileName and fileMode information
'''
print('Start line')

fileObject = open("demo.txt", "r") # FileNotFoundError:

print("File Name is :",fileObject.name)

print('File Mode is :', fileObject.mode)

print('end line')
'''


# How to accessing the file data (using for-loop)
'''
fileObject = open("demo.txt", "r")

for  i in fileObject:
    print(i)
'''

'''
fileObject = open("demo.txt", "r")

for  i in fileObject:
    print(i, end="")   
'''


## working with read() ##
'''
fileObject = open("demo.txt", "r")

data = fileObject.read()

print(data) 

print(len(data))
'''

## How to find the total number of words in a file
'''
fileObject = open("demo.txt", "r")

data = fileObject.read()

list_of_words = data.split()

print(list_of_words)

print("Total number of words are :",len(list_of_words))
'''

#print(len(open("demo.txt", "r").read().split()))


## How to find the total number of lines in a file
'''
fileObject = open("demo.txt", "r")

data = fileObject.read()

list_of_lines = data.splitlines()

print(list_of_lines)

print("Total number of lines are :",len(list_of_lines))
'''



## read() method
'''
fileObject = open("demo.txt", "r")

data = fileObject.read()

print(data) 
'''

## read(count) method
'''
fileObject = open("demo.txt", "r")

data = fileObject.read(4)

print(data) 
'''

'''
fileObject = open("demo.txt", "r")

data = fileObject.read(4)
print(data)

data2 = fileObject.read()
print(data2)
'''


# readline() method
'''
fileObject = open("demo.txt", "r")
data = fileObject.readline()
print(data)
'''

# readline(count) method
'''
fileObject = open("demo.txt", "r")
data = fileObject.readline(2)
print(data)
'''


'''
fileObject = open("demo.txt", "r")
data = fileObject.readline(2)
print(data)

data2 = fileObject.readline()
print(data2)
'''


# readlines() method
'''
fileObject = open("demo.txt", "r")
data = fileObject.readlines()  # ['line1', 'line2', 'line3',....]
print(data)
'''

# readlines(count) method
'''
fileObject = open("demo.txt", "r")
data = fileObject.readlines(2) # ['current_line']
print(data)
'''


## working with tell() and seek() methods
'''
fileObject = open("demo.txt", "r")

print("Initial File pointer position is :",fileObject.tell())

print(fileObject.read(4))
print("After reading data, File pointer position is :",fileObject.tell())
print()

print(fileObject.read(4))
print("After reading data, File pointer position is :",fileObject.tell())
print()

fileObject.seek(0)
print("After using seek() method, File pointer position is :",fileObject.tell())
print()

print(fileObject.read(4))
print("After reading data, File pointer position is :",fileObject.tell())
print()
'''

## working with close() method
'''
fileObject = open("demo.txt", "r")

print(fileObject.read(4))

fileObject.close()

print(fileObject.read(2)) # ValueError: I/O operation on closed file.
'''


####  working with write operation ####

## If given fileName not available then it will creates it
'''
fileObject = open("demo2.txt", "w")
print(fileObject)
'''

## If given fileName is available then it will delete it and re-create it
'''
fileObject = open("demo2.txt", "w")
print(fileObject)
'''


##
'''
fileObject = open("demo3.txt", "w")

fileObject.write('django is a web framework\ndjango is contains huge modules')

print('data created into file')
'''

##
'''
fileObject = open("demo4.txt", "w")

fileObject.write('django is a web framework\ndjango is contains huge modules')

fileObject.close()

print('data created into file')
'''

## If given fileName not available then it will create fileName
'''
fileObject = open("demo5.txt", "x")

fileObject.write('django is a web framework\ndjango is contains huge modules')

fileObject.close()

print('data created into file')
'''

## If given fileName is available then it will throws exception like FileExistsError
'''
fileObject = open("demo5.txt", "x")

fileObject.write('django is a web framework\ndjango is contains huge modules')

fileObject.close()

print('data created into file')
'''

## If given fileName not available then it will create fileName
'''
fileObject = open("demo6.txt", "a")

fileObject.write('django is a web framework\ndjango is contains huge modules')

fileObject.close()

print('data created into file')
'''

# If given fileName is available then it will append the new data at end position
'''
fileObject = open("demo6.txt", "a")

fileObject.write('\n\nPython is simple language\npython is portable language')

fileObject.close()

print('data created into file')
'''




























